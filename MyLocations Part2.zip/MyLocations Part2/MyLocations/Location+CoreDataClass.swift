//
//  Location+CoreDataClass.swift
//  MyLocations
//
//  Created by user191449 on 3/4/21.
//
//

import Foundation
import CoreData

@objc(Location)
public class Location: NSManagedObject {

}
