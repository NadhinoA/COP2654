//
//  Functions.swift
//  MyLocations
//
//  Created by user191449 on 3/4/21.
//

import Foundation

func afterDelay(_ seconds: Double, run: @escaping () -> Void) {
    DispatchQueue.main.asyncAfter(deadline: .now() + seconds, execute: run)
}
