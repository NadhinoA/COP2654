//
//  SecondViewController.swift
//  MyLocations
//
//  Created by user191449 on 2/28/21.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}
